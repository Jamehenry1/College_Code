#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	long size;
	int zone;
	int cr;
	int ac;
	int hp;
	char *name;
}creatures;