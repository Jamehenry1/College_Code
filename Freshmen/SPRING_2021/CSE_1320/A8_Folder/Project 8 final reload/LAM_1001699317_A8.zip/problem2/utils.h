#ifndef UTILS_H_
#define UTILS_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>


void remove_newline(char *str);
void release_tree(BTNode *root);
void printArray(BTNode *root);

#endif