/*
Name: Nghia Lam
ID: 1001699317
gcc RB.c lab4driver.c
./a.out < a.dat file
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "RB.lab4.h"

int main()
    {
    int inputBytes;
    char *inputString,*outputString;
    char formatString[100];
    int insertKeys,i,key;

    scanf("%d",&inputBytes);
    inputString=(char*) malloc(inputBytes);
    if (!inputString) 
    {
        printf("malloc failed %d\n",__LINE__);
        exit(0);
    }
    sprintf(formatString,"%%%ds",inputBytes);
    scanf(formatString,inputString);
    STinit();
    printf("input string: %s\n",inputString);
    STdeserialize(inputString);
    free(inputString);
    //STprintTree();
    printf("enter number of keys: ");
    scanf("%d",&insertKeys);
    for (i=0;i<insertKeys;i++) 
    {
        scanf("%d",&key);
        STinsert(key);
    }
    STprintTree();
    outputString=STserialize();
    printf("%lu %s\n",strlen(outputString)+1,outputString);
    //free(outputString);
}
